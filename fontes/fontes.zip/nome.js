<!--
  /* Sauda��o */
  var NOME = prompt('Entre com seu nome, por favor.', '');
  if (NOME == null) {
    NOME = 'Visitante Desconhecido';
  }
  document.write('Ol� ' + NOME + ', esteja a vontade.');
//-->
